CREATE VIEW BenchmarkAllocationRatioWorst AS
SELECT
    SourceTab,
    Method,
    ArgumentKey,
    PairDiscriminator,
    ElementCount,
    LoopCount,
    AVG(AllocationRatio) AS AvgAllocationRatio,
    MAX(AllocationRatio) AS WorstAllocationRatio,
    AVG(LeftAllocatedBytes) AS AvgLeftAllocatedBytes,
    AVG(RightAllocatedBytes) AS AvgRightAllocatedBytes,
    COUNT(*) AS SampleCount
FROM BenchmarkPairComparisons
WHERE RunStatus='Completed' AND AllocationRatio IS NOT NULL
GROUP BY SourceTab,Method,ArgumentKey,PairDiscriminator,ElementCount,LoopCount
ORDER BY AvgAllocationRatio DESC;

