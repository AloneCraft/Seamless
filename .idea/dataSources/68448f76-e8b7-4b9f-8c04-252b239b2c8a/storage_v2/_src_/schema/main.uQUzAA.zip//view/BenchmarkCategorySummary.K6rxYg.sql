CREATE VIEW BenchmarkCategorySummary AS
SELECT
    SourceTab,
    CASE
        WHEN Method IN('Sum','Average','Min','Max','MinBy','MaxBy','Aggregate','AggregateBy','Count','LongCount','CountBy','Any','All','Contains','SequenceEqual') THEN 'Aggregate'
        WHEN Method IN('Distinct','DistinctBy','Union','UnionBy','Intersect','IntersectBy','Except','ExceptBy') THEN 'Set'
        WHEN Method IN('Select','SelectMany','Cast','OfType','Chunk','Index','Zip') THEN 'Projection'
        WHEN Method IN('Join','GroupJoin','LeftJoin','RightJoin') THEN 'Join'
        WHEN Method IN('OrderBy','OrderByDescending','ThenBy','ThenByDescending','Order','OrderDescending','Reverse','Shuffle') THEN 'Order'
        WHEN Method IN('GroupBy','ToLookup') THEN 'Grouping'
        WHEN Method IN('Where','Skip','SkipWhile','SkipLast','Take','TakeWhile','TakeLast','First','FirstOrDefault','Last','LastOrDefault','Single','SingleOrDefault','ElementAt','ElementAtOrDefault','DefaultIfEmpty') THEN 'Filter'
        WHEN Method LIKE 'To%' THEN 'Materialize'
        ELSE 'Other'
    END AS Category,
    COUNT(*) AS SampleCount,
    AVG(MeanRatio) AS AvgMeanRatio,
    MAX(MeanRatio) AS WorstMeanRatio,
    AVG(AllocationRatio) AS AvgAllocationRatio
FROM BenchmarkPairComparisons
WHERE RunStatus='Completed'
GROUP BY SourceTab,Category
ORDER BY AvgMeanRatio DESC;

