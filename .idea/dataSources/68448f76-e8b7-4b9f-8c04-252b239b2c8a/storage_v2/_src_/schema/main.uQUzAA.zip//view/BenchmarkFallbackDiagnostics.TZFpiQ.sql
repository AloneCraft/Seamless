CREATE VIEW BenchmarkFallbackDiagnostics AS
SELECT
    FallbackDiagnostics.RunId,
    Runs.SourceTab,
    FallbackDiagnostics.Project,
    FallbackDiagnostics.Method,
    FallbackDiagnostics.CounterName,
    FallbackDiagnostics.CounterValue,
    FallbackDiagnostics.RecordedAt
FROM FallbackDiagnostics
INNER JOIN Runs ON Runs.RunId=FallbackDiagnostics.RunId
ORDER BY FallbackDiagnostics.CounterValue DESC;

