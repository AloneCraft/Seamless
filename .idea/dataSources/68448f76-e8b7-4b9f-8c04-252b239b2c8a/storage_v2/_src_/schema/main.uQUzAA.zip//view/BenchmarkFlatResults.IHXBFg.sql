CREATE VIEW BenchmarkFlatResults AS
SELECT
    Runs.RunId,
    Apps.AppKind,
    Runs.DisplayName,
    Runs.ExecutionProfile,
    Runs.SourceTab,
    Runs.CurrentStatus AS RunStatus,
    Cases.CaseId,
    Cases.CaseKey,
    Cases.Name,
    Cases.Project,
    Cases.Method,
    Cases.TypeFullName,
    Cases.SourceTabId,
    Cases.ArgumentKey,
    Cases.Side,
    Cases.PairDiscriminator,
    Jobs.JobId,
    Jobs.JobKey,
    Jobs.Status AS JobStatus,
    Jobs.ElementCount,
    Jobs.LoopCount,
    Jobs.AssignedLogicalCpu,
    Jobs.StartedAt,
    Jobs.FinishedAt,
    Jobs.FailureKind,
    Jobs.FailureReason,
    Measurements.MeasuredAt,
    MAX(CASE WHEN MetricValues.MetricName='MeanNanoseconds' THEN MetricValues.NumericValue END) AS MeanNanoseconds,
    MAX(CASE WHEN MetricValues.MetricName='ErrorNanoseconds' THEN MetricValues.NumericValue END) AS ErrorNanoseconds,
    MAX(CASE WHEN MetricValues.MetricName='StdDevNanoseconds' THEN MetricValues.NumericValue END) AS StdDevNanoseconds,
    MAX(CASE WHEN MetricValues.MetricName='AllocatedBytes' THEN MetricValues.NumericValue END) AS AllocatedBytes
FROM Jobs
INNER JOIN Runs ON Runs.RunId=Jobs.RunId
INNER JOIN Apps ON Apps.AppId=Runs.AppId
INNER JOIN Cases ON Cases.CaseId=Jobs.CaseId
LEFT JOIN Measurements ON Measurements.JobId=Jobs.JobId
LEFT JOIN MetricValues ON MetricValues.MeasurementId=Measurements.MeasurementId
GROUP BY Jobs.JobId;

