CREATE VIEW BenchmarkHistoryTrend AS
SELECT
    RunId,
    SourceTab,
    Method,
    ArgumentKey,
    PairDiscriminator,
    ElementCount,
    LoopCount,
    MeanRatio,
    AllocationRatio,
    LeftMeanNanoseconds,
    RightMeanNanoseconds,
    LeftFinishedAt
FROM BenchmarkPairComparisons
WHERE RunStatus='Completed'
ORDER BY SourceTab,Method,ArgumentKey,LeftFinishedAt;

