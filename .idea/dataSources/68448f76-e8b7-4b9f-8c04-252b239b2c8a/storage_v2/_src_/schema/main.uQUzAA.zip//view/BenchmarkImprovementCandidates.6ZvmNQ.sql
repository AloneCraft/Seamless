CREATE VIEW BenchmarkImprovementCandidates AS
SELECT
    SourceTab,
    Method,
    ArgumentKey,
    PairDiscriminator,
    ElementCount,
    LoopCount,
    LeftProject,
    RightProject,
    COUNT(*) AS SampleCount,
    AVG(MeanRatio) AS AvgMeanRatio,
    MAX(MeanRatio) AS WorstMeanRatio,
    AVG(AllocationRatio) AS AvgAllocationRatio,
    MAX(LeftFinishedAt) AS LastMeasuredAt,
    AVG(MeanRatio)+COALESCE(AVG(AllocationRatio),0)*0.25 AS ImprovementScore
FROM BenchmarkPairComparisons
WHERE RunStatus='Completed'
GROUP BY SourceTab,Method,ArgumentKey,PairDiscriminator,ElementCount,LoopCount,LeftProject,RightProject
ORDER BY ImprovementScore DESC;

