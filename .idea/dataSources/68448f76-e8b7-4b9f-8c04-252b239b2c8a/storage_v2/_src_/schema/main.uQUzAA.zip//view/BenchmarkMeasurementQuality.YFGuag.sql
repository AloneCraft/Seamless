CREATE VIEW BenchmarkMeasurementQuality AS
SELECT
    RunId,
    SourceTab,
    Project,
    Method,
    ArgumentKey,
    ElementCount,
    LoopCount,
    MeanNanoseconds,
    StdDevNanoseconds,
    ErrorNanoseconds,
    AssignedLogicalCpu,
    CASE WHEN MeanNanoseconds>0 THEN StdDevNanoseconds/MeanNanoseconds END AS StdDevRatio,
    CASE WHEN MeanNanoseconds>0 THEN ErrorNanoseconds/MeanNanoseconds END AS ErrorRatio
FROM BenchmarkFlatResults
WHERE JobStatus='Completed' AND MeanNanoseconds IS NOT NULL
ORDER BY StdDevRatio DESC;

