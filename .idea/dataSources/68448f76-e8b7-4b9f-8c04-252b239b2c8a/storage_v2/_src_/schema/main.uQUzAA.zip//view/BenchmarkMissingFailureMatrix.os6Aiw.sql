CREATE VIEW BenchmarkMissingFailureMatrix AS
SELECT
    leftResult.RunId,
    leftResult.SourceTab,
    leftResult.Method,
    leftResult.ArgumentKey,
    leftResult.PairDiscriminator,
    leftResult.ElementCount,
    leftResult.LoopCount,
    leftResult.Project,
    leftResult.Side,
    leftResult.JobStatus,
    leftResult.FailureKind,
    leftResult.FailureReason,
    CASE WHEN opposite.JobId IS NULL THEN 1 ELSE 0 END AS OppositeMissing
FROM BenchmarkFlatResults leftResult
LEFT JOIN BenchmarkFlatResults opposite
    ON opposite.RunId=leftResult.RunId
    AND opposite.Method=leftResult.Method
    AND opposite.ArgumentKey=leftResult.ArgumentKey
    AND opposite.PairDiscriminator=leftResult.PairDiscriminator
    AND COALESCE(opposite.ElementCount,-1)=COALESCE(leftResult.ElementCount,-1)
    AND COALESCE(opposite.LoopCount,-1)=COALESCE(leftResult.LoopCount,-1)
    AND opposite.Side<>leftResult.Side
    AND opposite.Side IN('Left','Right')
WHERE leftResult.Side IN('Left','Right')
    AND (leftResult.JobStatus='Failed' OR opposite.JobId IS NULL);

