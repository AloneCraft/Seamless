CREATE VIEW BenchmarkPairComparisons AS
SELECT
    leftResult.RunId,
    leftResult.AppKind,
    leftResult.SourceTab,
    leftResult.SourceTabId,
    leftResult.RunStatus,
    leftResult.Method,
    leftResult.ArgumentKey,
    leftResult.PairDiscriminator,
    leftResult.ElementCount,
    leftResult.LoopCount,
    leftResult.Project AS LeftProject,
    rightResult.Project AS RightProject,
    leftResult.TypeFullName AS LeftTypeFullName,
    rightResult.TypeFullName AS RightTypeFullName,
    leftResult.MeanNanoseconds AS LeftMeanNanoseconds,
    rightResult.MeanNanoseconds AS RightMeanNanoseconds,
    CASE
        WHEN rightResult.MeanNanoseconds IS NULL OR rightResult.MeanNanoseconds=0 THEN NULL
        ELSE leftResult.MeanNanoseconds/rightResult.MeanNanoseconds
    END AS MeanRatio,
    leftResult.AllocatedBytes AS LeftAllocatedBytes,
    rightResult.AllocatedBytes AS RightAllocatedBytes,
    CASE
        WHEN rightResult.AllocatedBytes IS NULL OR rightResult.AllocatedBytes=0 THEN NULL
        ELSE leftResult.AllocatedBytes/rightResult.AllocatedBytes
    END AS AllocationRatio,
    leftResult.StdDevNanoseconds AS LeftStdDevNanoseconds,
    rightResult.StdDevNanoseconds AS RightStdDevNanoseconds,
    leftResult.FinishedAt AS LeftFinishedAt,
    rightResult.FinishedAt AS RightFinishedAt
FROM BenchmarkFlatResults leftResult
INNER JOIN BenchmarkFlatResults rightResult
    ON rightResult.RunId=leftResult.RunId
    AND leftResult.Side='Left'
    AND rightResult.Side='Right'
    AND rightResult.Method=leftResult.Method
    AND rightResult.ArgumentKey=leftResult.ArgumentKey
    AND rightResult.PairDiscriminator=leftResult.PairDiscriminator
    AND COALESCE(rightResult.ElementCount,-1)=COALESCE(leftResult.ElementCount,-1)
    AND COALESCE(rightResult.LoopCount,-1)=COALESCE(leftResult.LoopCount,-1)
WHERE leftResult.JobStatus='Completed'
    AND rightResult.JobStatus='Completed'
    AND leftResult.MeanNanoseconds IS NOT NULL
    AND rightResult.MeanNanoseconds IS NOT NULL;

