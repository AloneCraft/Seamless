CREATE VIEW BenchmarkScaleTrend AS
SELECT
    SourceTab,
    Method,
    ArgumentKey,
    PairDiscriminator,
    ElementCount,
    LoopCount,
    COUNT(*) AS SampleCount,
    AVG(MeanRatio) AS AvgMeanRatio,
    AVG(LeftMeanNanoseconds) AS AvgLeftMeanNanoseconds,
    AVG(RightMeanNanoseconds) AS AvgRightMeanNanoseconds
FROM BenchmarkPairComparisons
WHERE RunStatus='Completed'
GROUP BY SourceTab,Method,ArgumentKey,PairDiscriminator,ElementCount,LoopCount
ORDER BY SourceTab,Method,ArgumentKey,ElementCount,LoopCount;

