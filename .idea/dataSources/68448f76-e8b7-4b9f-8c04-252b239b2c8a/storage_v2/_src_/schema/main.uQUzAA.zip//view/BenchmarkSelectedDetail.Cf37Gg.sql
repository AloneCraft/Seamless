CREATE VIEW BenchmarkSelectedDetail AS
SELECT
    UiSelections.RunId,
    UiSelections.Scope,
    UiSelections.SelectionKey,
    BenchmarkFlatResults.CaseKey,
    BenchmarkFlatResults.Project,
    BenchmarkFlatResults.Method,
    BenchmarkFlatResults.ArgumentKey,
    BenchmarkFlatResults.Side,
    BenchmarkFlatResults.ElementCount,
    BenchmarkFlatResults.LoopCount,
    BenchmarkFlatResults.JobStatus,
    BenchmarkFlatResults.MeanNanoseconds,
    BenchmarkFlatResults.AllocatedBytes,
    BenchmarkFlatResults.FinishedAt
FROM UiSelections
LEFT JOIN BenchmarkFlatResults
    ON BenchmarkFlatResults.RunId=UiSelections.RunId
    AND (BenchmarkFlatResults.Name=UiSelections.SelectionKey OR BenchmarkFlatResults.CaseKey=UiSelections.SelectionKey)
WHERE UiSelections.IsSelected=1;

