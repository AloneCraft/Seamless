CREATE VIEW BenchmarkTimeRatioWorst AS
SELECT
    SourceTab,
    Method,
    ArgumentKey,
    PairDiscriminator,
    ElementCount,
    LoopCount,
    AVG(MeanRatio) AS AvgMeanRatio,
    MAX(MeanRatio) AS WorstMeanRatio,
    COUNT(*) AS SampleCount,
    MAX(LeftFinishedAt) AS LastMeasuredAt
FROM BenchmarkPairComparisons
WHERE RunStatus='Completed'
GROUP BY SourceTab,Method,ArgumentKey,PairDiscriminator,ElementCount,LoopCount
ORDER BY AvgMeanRatio DESC;

