CREATE VIEW BenchmarkTrendResults AS
SELECT
    RunId,
    AppKind,
    SourceTab,
    Project,
    Method,
    TypeFullName,
    ArgumentKey,
    Side,
    ElementCount,
    LoopCount,
    Name,
    MeanNanoseconds,
    AllocatedBytes,
    FinishedAt,
    MeasuredAt
FROM BenchmarkFlatResults
WHERE JobStatus='Completed'
ORDER BY SourceTab,Project,Method,TypeFullName,ElementCount,LoopCount,FinishedAt;

